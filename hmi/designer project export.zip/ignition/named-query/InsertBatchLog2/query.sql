INSERT INTO batch_log (
    batch_number, 
    recipe, 
    target_weight, 
    actual_weight, 
    start_time, 
    end_time, 
    result
) 
VALUES (
    :batch_number, 
    :recipe, 
    :target_weight, 
    :actual_weight, 
    :start_time, 
    :end_time, 
    :result
)